/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Aspire
 */
public class Administrador extends Persona{
    private String Contraseña;
    private String rol;

    public Administrador(String Contraseña, String rol,String ID, String nombre, String apellido, String correo, String telefono, String estatus) {
        super( ID, nombre,apellido, correo,telefono, estatus);
        this.Contraseña = Contraseña;
        this.rol = rol;
    }
    
    public Administrador(){
        ID = "01";
        nombre = "Admin";
        apellido = "Usuario";
        correo = "admin@gmail.com";
        Contraseña = "123";
        rol = "Administrador";
        estatus = "Activo";
        telefono = "0212";
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
    
    
    
}
