/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author Aspire
 */
public class Persona {
    protected String ID; 
    protected String nombre;
    protected String apellido;
    protected String correo;
    protected String telefono;
    protected String estatus;

    public Persona(String ID, String nombre,String apellido,String correo,String telefono, String estatus) {
        this.ID = ID;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.telefono = telefono;
        this.estatus = estatus;
    }

    public Persona(){
        ID = "";
        nombre = "";
        apellido = "";
        correo = "";
        telefono = "04140289733";
        estatus = "";
    }
    
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }
    
    public boolean validarNombre(String nombre) { //Valida nombre 
       int i,as;
        char a;
        for (i=0; nombre.length()>i;i++){
            a= nombre.charAt(i);
            as= (int)a;
            if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                JOptionPane.showMessageDialog(null, "Nombre inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            } 
            if((as>=48 && 57>=as)==true){
                JOptionPane.showMessageDialog(null, "Nombre inválido.\nContiene algun dígito", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }       
        }            
        return true;
    }  
    
     public boolean validarApellido(String apellido) { //Valida nombre 
       int i,as;
        char a;
        for (i=0; apellido.length()>i;i++){
            a= apellido.charAt(i);
            as= (int)a;
            if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                JOptionPane.showMessageDialog(null, "Apellido inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            } 
            if((as>=48 && 57>=as)==true){
                JOptionPane.showMessageDialog(null, "Apellido inválido.\nContiene algun dígito", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }       
        }            
        return true;
    }
    
     public boolean validarID (String id) { //Valida ID
        
                int i,as;
                char a;
                for (i=0; id.length()>i;i++){
                    a= id.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= id.length();
                        JOptionPane.showMessageDialog(null, "ID inválida.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= id.length();
                        JOptionPane.showMessageDialog(null, "ID inválida.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
        
        }
    
     public boolean validarNumero (String numero) { //Valida cedula
        int i,as;
        char a;
                for (i=0; numero.length()>i;i++){
                    a= numero.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= numero.length();
                        JOptionPane.showMessageDialog(null, "N. Telefono inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= numero.length();
                        JOptionPane.showMessageDialog(null, "N. Telefono inválido.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
    }
    
     public boolean validarCorreo(String correo){
      
        String patron1 = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.([a-zA-Z]{2,4})+";     
       Pattern pat = Pattern.compile(patron1);
       Matcher mat = pat.matcher(correo);
       
        if(!(mat.matches())){
            JOptionPane.showMessageDialog(null,"Correo invalido","advertencia",JOptionPane.WARNING_MESSAGE);
            return false;
        }else
            return true;
     }
}
