/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Administrador;
import model.Analista;
import model.Coordinador;
import model.Estudiante;
import model.OfertaFormativa;
import model.Persona;
import model.Profesor;
import model.Usuario;
import view.AgregarEst;
import view.AgregarOF;
import view.AgregarPersona;
import view.AgregarProf;
import view.ModificarU;
import view.ModificarEst;
import view.ModificarOF;
import view.ModificarProf;
import view.GestionLista;
import view.InicioSesion;
import view.PanelEst;
import view.PanelInicio;
import view.PanelOF;
import view.PanelProf;
import view.PanelUsuario;
import view.VentanaInicial;
import view.VentanaPrincipal;
import view.barraGestion;
import view.barraGestionEst;
import view.barraGestionProf;
import view.barraGestionU;


public class Controladora implements ActionListener{
    private VentanaInicial vi;
    private AgregarEst agregarEst = new AgregarEst();
    private AgregarOF agregarOF = new AgregarOF();
    private AgregarProf agregarProf = new AgregarProf();
    private AgregarPersona agregarP = new AgregarPersona();
    private ModificarU modU = new ModificarU();
    private GestionLista gestionList = new GestionLista();
    private InicioSesion is = new InicioSesion();
    private VentanaPrincipal ventanaP = new VentanaPrincipal();
    private PanelEst pest = new PanelEst();
    private PanelInicio pi = new PanelInicio();
    private PanelUsuario pu = new PanelUsuario();
    private PanelOF pof = new PanelOF();
    private PanelProf pprof = new PanelProf();
    private barraGestion barraGestion = new barraGestion();
    private barraGestionU barraGestionU = new barraGestionU();
    private barraGestionEst barraEst = new barraGestionEst();
    private barraGestionProf barraProf = new barraGestionProf();
    private Persona p = new Persona();
    private Administrador admin = new Administrador();
    private Analista analist = new Analista();
    private Coordinador coord = new Coordinador();
    private Estudiante estudiante = new Estudiante();
    private OfertaFormativa OF = new OfertaFormativa();
    private Profesor prof = new Profesor();
    private Usuario user = new Usuario();
    private DefaultTableModel model1,model2,model3,model4;
    private ArrayList<Estudiante> listaEst = new ArrayList<>();
    private ArrayList<OfertaFormativa> listaOF = new ArrayList<>();
    private ArrayList<Profesor> listaProf = new ArrayList<>();
    DecimalFormat formato = new DecimalFormat("##.00");
    
    
    public Controladora(VentanaInicial vi){
        //Inicio de sesion (inicia el programa)
        this.vi = vi;
        this.is.btnIngresar.addActionListener(this);
        //Panel Ventana Principal
        this.ventanaP.btnOF.addActionListener(this);
        this.ventanaP.btnInicio.addActionListener(this);
        this.ventanaP.btnEstudiante.addActionListener(this);
        this.ventanaP.btnUsuario.addActionListener(this);
        this.ventanaP.btnProfesor.addActionListener(this);
        this.ventanaP.btnCerrarSesion.addActionListener(this);
        this.ventanaP.btnMinimizar.addActionListener(this);
        //Panel agregar Oferta Formativa
        this.agregarOF.btnAñadirOF.addActionListener(this);
        //Panel Agregar Persona
        this.agregarP.btnAñadirF.addActionListener(this);
        //Panel Agregar estudiante
        this.agregarEst.btnAñadirEst.addActionListener(this);
        //Panel Agregar Profesor
        this.agregarProf.btnAñadirProf.addActionListener(this);
        //Panel Modificar Usuario
        this.modU.btnModU.addActionListener(this);
        //Panel Gestion Lista
        this.gestionList.btnBuscar.addActionListener(this);
        //Panel barra de gestion
        this.barraGestion.btnCrear.addActionListener(this);
        this.barraGestion.btnEliminar.addActionListener(this);
        this.barraGestion.btnModificar.addActionListener(this);
        this.barraGestion.btnListar.addActionListener(this);
        //Panel barra de gestion de usuario
        this.barraGestionU.btnAñadir.addActionListener(this);
        this.barraGestionU.btnEliminarU.addActionListener(this);
        this.barraGestionU.btnModificarU.addActionListener(this);
        this.barraGestionU.btnListadoU.addActionListener(this);
        //Panel barra gestion de estudiante
        this.barraEst.btnAñadirEst.addActionListener(this);
        this.barraEst.btnEliminarEst.addActionListener(this);
        this.barraEst.btnListarEst.addActionListener(this);
        this.barraEst.btnModificarEst.addActionListener(this);
        //Panel barra gestion de profesor
        this.barraProf.btnAñadirProf.addActionListener(this);
        this.barraProf.btnEliminarProf.addActionListener(this);
        this.barraProf.btnListarProf.addActionListener(this);
        this.barraProf.btnModificarProf.addActionListener(this);
        this.listaEst = new ArrayList<>();
        this.listaProf = new ArrayList<>();
        this.listaOF = new ArrayList<>();
        user.agregarAdmin(admin);
        user.agregarCoord(coord);
        user.agregarAnalista(analist);
        user.agregarProf(prof);
        listaProf.add(prof);
        
    }
    
    
    public void iniciarVentana(){
        is.setSize(720,520);
        is.setLocation(0,0);
        vi.setSize(720, 520);
        vi.setLocationRelativeTo(null); //Iniciar el frame en el centro de la pantalla
        vi.setResizable(false);
        vi.panelVI.add(is);
        vi.panelVI.revalidate();
        vi.panelVI.repaint();
        is.btnIngresar.setBackground(new Color(255,255,255));
    }
    
    //Validar si los campos correspondientes estan vacios 
    
    public boolean validarCampoIS(){ //Inicio de sesion
        return !(is.campoCorreo.getText().isEmpty() || Arrays.toString(is.campoContraseña.getPassword()).isEmpty());
    }
    public boolean validarCampoAgregarP(){ //Agregar Persona
        return !(agregarP.CampoContraseña.getText().equals("Contraseña")|| agregarP.campoApellido.getText().equals("Apellido")||
                agregarP.campoCorreo.getText().equals("correo@gmail.com") || agregarP.campoID.getText().equals("ID") ||
                agregarP.campoNombre.getText().equals("Nombre") || agregarP.campoTelefono.getText().equals("Telefono") ||
                agregarP.CampoContraseña.getText().isEmpty() || agregarP.campoApellido.getText().isEmpty() ||
                agregarP.campoCorreo.getText().isEmpty() || agregarP.campoID.getText().isEmpty() || agregarP.campoNombre.getText().isEmpty() ||
                agregarP.campoTelefono.getText().isEmpty());
    }
    
    public boolean validarCampoAgregarEst(){ //Agregar Estudiante
        return !(agregarEst.campoNota.getText().equals("Nota") ||agregarEst.CampoCursoEST.getText().equals("Curso") || agregarEst.campoApellido.getText().equals("Apellido") ||
                agregarEst.campoCorreo.getText().equals("Correo") || agregarEst.campoID.getText().equals("ID") ||
                agregarEst.campoNombre.getText().equals("Nombre") || agregarEst.campoTelefono.getText().equals("Telefono") ||
                agregarEst.campoApellido.getText().isEmpty() || agregarEst.CampoCursoEST.getText().isEmpty() ||
                agregarEst.campoCorreo.getText().isEmpty() || agregarEst.campoID.getText().isEmpty() || agregarEst.campoNombre.getText().isEmpty() ||
                agregarEst.campoTelefono.getText().isEmpty() || agregarEst.campoNota.getText().isEmpty() );
    }
    
    public boolean validarCampoAgregarProf(){ //Agregar Profesor
        return !(agregarProf.CampoContraseña.getText().equals("Contraseña") || agregarProf.campoApellido.getText().equals("Apellido") ||
                agregarProf.campoCorreo.getText().equals("Correo") || agregarProf.campoID.getText().equals("ID") ||
                agregarProf.campoNombre.getText().equals("Nombre") || agregarProf.campoTelefono.getText().equals("Telefono") || agregarProf.campoTitulacion.getText().equals("Titulacion") ||
                agregarProf.CampoContraseña.getText().isEmpty() || agregarProf.campoApellido.getText().isEmpty() ||
                agregarProf.campoCorreo.getText().isEmpty() || agregarProf.campoID.getText().isEmpty() || agregarProf.campoNombre.getText().isEmpty() ||
                agregarProf.campoTelefono.getText().isEmpty()) || agregarProf.campoTitulacion.getText().isEmpty();
    }
    
    public boolean validarCampoOF(){ //Agregar Oferta Formativa
        return !(agregarOF.CampoCodigoOF.getText().equals("Codigo") || agregarOF.CampoCostoOF.getText().equals("Costo") ||
                agregarOF.CampoCursoEOF.getText().equals("Curso") || agregarOF.CampoEdicionOF.getText().equals("Edicion") ||
                agregarOF.CampoHorasOF.getText().equals("Horas") || agregarOF.CampoNombreOF.getText().equals("Nombre") ||
                agregarOF.CampoCodigoOF.getText().isEmpty() || agregarOF.CampoCostoOF.getText().isEmpty() ||
                 agregarOF.CampoCursoEOF.getText().isEmpty() || agregarOF.CampoDescripcionOF.getText().isEmpty() || agregarOF.CampoEdicionOF.getText().isEmpty() ||
                agregarOF.CampoHorasOF.getText().isEmpty()  || agregarOF.CampoNombreOF.getText().isEmpty() ); 
    }
    
    public boolean validarModU(){
        return !(modU.CampoContraseña.getText().isEmpty() || modU.campoApellido.getText().isEmpty() || modU.campoCorreo.getText().isEmpty() ||
                modU.campoID.getText().isEmpty() || modU.campoNombre.getText().isEmpty() || modU.campoTelefono.getText().isEmpty() );
    }
    
    //BORRA TODOS LOS CAMPSO CORRESPONDIENTES PARA MANTENERLOS EN BLANCO
    
    public void borrarCampoIS(){
       is.campoCorreo.setText("");
       is.campoContraseña.setText("");
    }
    
    public void borrarCampoAgregarP(){ //Agregar persona
        agregarP.CampoContraseña.setText("");
        agregarP.campoApellido.setText("");
        agregarP.campoCorreo.setText("");
        agregarP.campoID.setText("");
        agregarP.campoNombre.setText("");
        agregarP.campoTelefono.setText("");
    }
    
    public void borrarCampoAgregarEst(){ //Agregar Estudiante
        agregarEst.CampoCursoEST.setText("");
        agregarEst.campoApellido.setText("");
        agregarEst.campoCorreo.setText("");
        agregarEst.campoID.setText("");
        agregarEst.campoNombre.setText("");
        agregarEst.campoTelefono.setText("");
           
    }
    
     public void borrarCampoAgregarProf(){ //Agregar Profesor
        agregarProf.CampoContraseña.setText("");
        agregarProf.campoApellido.setText("");
        agregarProf.campoCorreo.setText("");
        agregarProf.campoID.setText("");
        agregarProf.campoNombre.setText("");
        agregarProf.campoTelefono.setText("");
        agregarProf.campoTitulacion.setText("");
    }
     
     public void borrarCampoOF(){ //Agregar Oferta Formativa
         agregarOF.CampoCodigoOF.setText("");
         agregarOF.CampoCostoOF.setText("");
         agregarOF.CampoCursoEOF.setText("");
         agregarOF.CampoDescripcionOF.setText("");
         agregarOF.CampoEdicionOF.setText("");
         agregarOF.CampoHorasOF.setText("");
         agregarOF.CampoNombreOF.setText("");
     }
    
    public boolean idRepetida(String c) {
        boolean repetido = false;
        int i = 0;
        while (!repetido && i<user.getListaUsuario().size()){
            if (user.getListaUsuario().get(i).getID().equals(c))repetido = true;
            i++;
        }
        return repetido;
    }
    
    public boolean idRepetidaEst(String c){
        boolean repetido = false;
        int i = 0;
        while (!repetido && i<listaEst.size()){
            if (listaEst.get(i).getID().equals(c))repetido = true;
            i++;
        }
        return repetido;
    }
    
    public boolean userEncontrado(String c) {
        boolean repetido = false;
        int i = 0;
        while (!repetido && i<user.getListaUsuario().size()){
            if (user.getListaUsuario().get(i).getCorreo().equals(c))repetido = true;
            i++;
        }
        return repetido;
    }
    
    public void restaurarBotones(){
        //Botones ventana Principal
        ventanaP.btnEstudiante.setEnabled(true);
        ventanaP.btnOF.setEnabled(true);
        ventanaP.btnProfesor.setEnabled(true);
        ventanaP.btnUsuario.setEnabled(true);
        //Botones barras de gestion
        barraGestionU.btnAñadir.setEnabled(true);
        barraGestionU.btnEliminarU.setEnabled(true);
        barraGestionU.btnModificarU.setEnabled(true);
        barraGestion.btnCrear.setEnabled(true);
        barraGestion.btnEliminar.setEnabled(true);
        barraGestion.btnModificar.setEnabled(true);
        barraEst.btnAñadirEst.setEnabled(true);
        barraEst.btnEliminarEst.setEnabled(true);
        barraEst.btnModificarEst.setEnabled(true);
        barraProf.btnAñadirProf.setEnabled(true);
        barraProf.btnEliminarProf.setEnabled(true);
        barraProf.btnModificarProf.setEnabled(true);
    }
    
    public void botonesU(){
        ventanaP.btnEstudiante.setEnabled(false);
        ventanaP.btnOF.setEnabled(false);
        ventanaP.btnProfesor.setEnabled(false);
    }
    
    public void botonesCoord(){
        ventanaP.btnUsuario.setEnabled(false);
    }
    
    public void botonesAnalist(){
        barraGestionU.btnAñadir.setEnabled(false);
        barraGestionU.btnEliminarU.setEnabled(false);
        barraGestionU.btnModificarU.setEnabled(false);
        barraGestion.btnCrear.setEnabled(false);
        barraGestion.btnEliminar.setEnabled(false);
        barraGestion.btnModificar.setEnabled(false);
        barraEst.btnAñadirEst.setEnabled(false);
        barraEst.btnEliminarEst.setEnabled(false);
        barraEst.btnModificarEst.setEnabled(false);
        barraProf.btnAñadirProf.setEnabled(false);
        barraProf.btnEliminarProf.setEnabled(false);
        barraProf.btnModificarProf.setEnabled(false);
        
    }
    
    public void botonesProf(){
        ventanaP.btnEstudiante.setEnabled(false);
        ventanaP.btnOF.setEnabled(false);
        ventanaP.btnUsuario.setEnabled(false);
        barraProf.btnAñadirProf.setEnabled(false);
        barraProf.btnEliminarProf.setEnabled(false);
        barraProf.btnModificarProf.setEnabled(false);
    }
    
    public void botonesModificar(){
        barraGestionU.btnAñadir.setEnabled(false);
        barraGestionU.btnEliminarU.setEnabled(false);
    }
    
     public void restauraBotonesModificar(){
        barraGestionU.btnAñadir.setEnabled(true);
        barraGestionU.btnEliminarU.setEnabled(true);
    }
    
    public boolean userBuscado(String c,String correo) {
        boolean repetido = false;
        int i = 0;
        
        while (!repetido && i<user.getListaUsuario().size()){
            Persona perso = user.getListaUsuario().get(i);
           if(perso instanceof Administrador admin){
               if(admin.getContraseña().equals(c) && admin.getCorreo().equals(correo))repetido=true;
               i++;
               restaurarBotones();
               botonesU();
           }else{
              if(perso instanceof Coordinador coord ){
               if(coord.getContrasena().equals(c) && coord.getCorreo().equals(correo))repetido=true;
               i++;
               restaurarBotones();
               botonesCoord();
           }else{
                if(perso instanceof Analista analist){
               if(analist.getContraseña().equals(c) && analist.getCorreo().equals(correo))repetido=true;
               i++;
               restaurarBotones();
               botonesAnalist();
           }else{
                 if(perso instanceof Profesor prof){
               if(prof.getContraseña().equals(c) && prof.getCorreo().equals(correo))repetido=true;
               i++;
               restaurarBotones();
               botonesProf();
                }
          }
         }
        }
     
    }
        return repetido;
   }
    
    public boolean correoRepetido(String c) {
        boolean repetido = false;
        int i = 0;
        while (!repetido && i<user.getListaUsuario().size()){
          
           
            if (user.getListaUsuario().get(i).getCorreo().equals(c))repetido = true;
            i++;
        }  
    
        return repetido;
   }
    
    public boolean correoRepetidoEst(String c) {
        boolean repetido = false;
        int i = 0;
        while (!repetido && i<listaEst.size()){
            if (listaEst.get(i).getCorreo().equals(c))repetido = true;
            i++;
        }
        return repetido;
    }
    
    public boolean encuentraCurso(String curso){
        boolean encontrado = false;
        for(int i=0;i<listaEst.size();i++){
           if(listaEst.get(i).getCurso().equals(curso)){
               encontrado = true;
           }
               
        }
        return encontrado;
    }
    
    public boolean codigoRepetido(String c) {
        boolean repetido = false;
        int i = 0;
        while (!repetido && i<listaOF.size()){
            if (listaOF.get(i).getCodigo().equals(c))repetido = true;
            i++;
        }
        return repetido;
    }
    
    public void cargarTablaUsuario(){
        String datos[][] = {};
        String columna [] = {"ID","Nombre","Correo","Estatus","Rol"};
        model1 = new DefaultTableModel(datos, columna){
            @Override
            public boolean isCellEditable(int rowIndex,int columnIndex) {return false;}
        };
        
         gestionList.Lista.setModel(model1);
        gestionList.Lista.getTableHeader().setReorderingAllowed(false);
        gestionList.Lista.getTableHeader().setResizingAllowed(false);
        gestionList.Lista.getColumnModel().getColumn(0).setPreferredWidth(35);
        gestionList.Lista.getColumnModel().getColumn(1).setPreferredWidth(35);
        gestionList.Lista.getColumnModel().getColumn(2).setPreferredWidth(50);
        gestionList.Lista.getColumnModel().getColumn(3).setPreferredWidth(30);
        gestionList.Lista.getColumnModel().getColumn(4).setPreferredWidth(30);
        
        for(int i=0;i<user.getListaUsuario().size();i++){
           Persona persona = user.getListaUsuario().get(i);
           if (persona instanceof Administrador admin){
                model1.insertRow(0, columna);
                model1.setValueAt(admin.getID(), 0, 0);
                model1.setValueAt(admin.getNombre(), 0, 1);
                model1.setValueAt(admin.getCorreo(), 0, 2);
                model1.setValueAt(admin.getEstatus(), 0, 3);
                model1.setValueAt(admin.getRol(), 0, 4);
            
        }
           
           if (persona instanceof Coordinador coord){
                model1.insertRow(0, columna);
                model1.setValueAt(coord.getID(), 0, 0);
                model1.setValueAt(coord.getNombre(), 0, 1);
                model1.setValueAt(coord.getCorreo(), 0, 2);
                model1.setValueAt(coord.getEstatus(), 0, 3);
                model1.setValueAt(coord.getRol(), 0, 4);
            
        }
           
           if (persona instanceof Analista analist){
                model1.insertRow(0, columna);
                model1.setValueAt(analist.getID(), 0, 0);
                model1.setValueAt(analist.getNombre(), 0, 1);
                model1.setValueAt(analist.getCorreo(), 0, 2);
                model1.setValueAt(analist.getEstatus(), 0, 3);
                model1.setValueAt(analist.getRol(), 0, 4);
            
        }
           
         
           
        }  
    }
    
    public void cargarTablaEstudiante(){
        String datos[][] = {};
        String columna [] = {"ID","Nombre","Apellido","Correo","Estatus","Curso"};
        model2 = new DefaultTableModel(datos, columna){
            @Override
            public boolean isCellEditable(int rowIndex,int columnIndex) {return false;}
        };
        
         gestionList.Lista.setModel(model2);
        gestionList.Lista.getTableHeader().setReorderingAllowed(false);
        gestionList.Lista.getTableHeader().setResizingAllowed(false);
        gestionList.Lista.getColumnModel().getColumn(0).setPreferredWidth(40);
        gestionList.Lista.getColumnModel().getColumn(1).setPreferredWidth(45);
        gestionList.Lista.getColumnModel().getColumn(2).setPreferredWidth(45);
        gestionList.Lista.getColumnModel().getColumn(3).setPreferredWidth(40);
        gestionList.Lista.getColumnModel().getColumn(4).setPreferredWidth(30);
        gestionList.Lista.getColumnModel().getColumn(5).setPreferredWidth(25);
        
        for(int i=0;i<listaEst.size();i++){
            Estudiante est = listaEst.get(i);
            
                model2.insertRow(0, columna);
                model2.setValueAt(est.getID(), 0, 0);
                model2.setValueAt(est.getNombre(), 0, 1);
                model2.setValueAt(est.getApellido(), 0, 2);
                model2.setValueAt(est.getCorreo(), 0, 3);
                model2.setValueAt(est.getEstatus(), 0, 4);
                model2.setValueAt(est.getCurso(),0,5);
            
        }
        
    }
    
    public void cargarTablaProf(){
        String datos[][] = {};
        String columna [] = {"ID","Nombre","Correo","Titulo","Estatus"};
        model3 = new DefaultTableModel(datos, columna){
            @Override
            public boolean isCellEditable(int rowIndex,int columnIndex) {return false;}
        };
        
         gestionList.Lista.setModel(model3);
        gestionList.Lista.getTableHeader().setReorderingAllowed(false);
        gestionList.Lista.getTableHeader().setResizingAllowed(false);
        gestionList.Lista.getColumnModel().getColumn(0).setPreferredWidth(35);
        gestionList.Lista.getColumnModel().getColumn(1).setPreferredWidth(35);
        gestionList.Lista.getColumnModel().getColumn(2).setPreferredWidth(50);
        gestionList.Lista.getColumnModel().getColumn(3).setPreferredWidth(30);
        gestionList.Lista.getColumnModel().getColumn(4).setPreferredWidth(30);
        
        for(int i=0;i<listaProf.size();i++){
           Profesor prof = listaProf.get(i);
                model3.insertRow(0, columna);
                model3.setValueAt(prof.getID(), 0, 0);
                model3.setValueAt(prof.getNombre(), 0, 1);
                model3.setValueAt(prof.getCorreo(), 0, 2);
                model3.setValueAt(prof.getTitulacion(), 0, 3);
                model3.setValueAt(prof.getEstatus(), 0, 4);
               
            
        }
    }
    
    public void cargarTablaOF(){
         String datos[][] = {};
        String columna [] = {"Codigo","Nombre","Tipo","Edicion","Horas","Costo"};
        model4 = new DefaultTableModel(datos, columna){
            @Override
            public boolean isCellEditable(int rowIndex,int columnIndex) {return false;}
        };
        
         gestionList.Lista.setModel(model4);
        gestionList.Lista.getTableHeader().setReorderingAllowed(false);
        gestionList.Lista.getTableHeader().setResizingAllowed(false);
        gestionList.Lista.getColumnModel().getColumn(0).setPreferredWidth(40);
        gestionList.Lista.getColumnModel().getColumn(1).setPreferredWidth(50);
        gestionList.Lista.getColumnModel().getColumn(2).setPreferredWidth(40);
        gestionList.Lista.getColumnModel().getColumn(3).setPreferredWidth(30);
        gestionList.Lista.getColumnModel().getColumn(4).setPreferredWidth(30);
        gestionList.Lista.getColumnModel().getColumn(5).setPreferredWidth(25);
        
        for(int i=0;i<listaOF.size();i++){
            OfertaFormativa of = listaOF.get(i);
                model4.insertRow(0, columna);
                model4.setValueAt(of.getCodigo(), 0, 0);
                model4.setValueAt(of.getNombre(), 0, 1);
                model4.setValueAt(of.getTipo(), 0, 2);
                model4.setValueAt(of.getEdicion(), 0, 3);
                model4.setValueAt(of.gettHoras(), 0, 4);
                model4.setValueAt(of.getCosto(), 0, 5);
        }
    }
    
    public void modificarU(int fila){
        Collections.reverse(user.getListaUsuario());
        barraGestionU.setSize(580,30);
        barraGestionU.setLocation(0,0);
        modU.setSize(580,500);
        modU.setLocation(0,0);
        ventanaP.PanelMuestra.removeAll();
        ventanaP.PanelMuestra.add(barraGestionU);
        ventanaP.PanelMuestra.add(modU);
        ventanaP.PanelMuestra.revalidate();
        ventanaP.PanelMuestra.repaint();
        
        Persona perso = user.getListaUsuario().get(fila);
        modU.campoID.setText(user.getListaUsuario().get(fila).getID());
        if(perso instanceof Administrador admin){
        modU.CampoContraseña.setText(admin.getContraseña());
        }
        modU.campoApellido.setText(user.getListaUsuario().get(fila).getApellido());
        modU.campoNombre.setText(user.getListaUsuario().get(fila).getNombre());
        modU.campoID.setText(user.getListaUsuario().get(fila).getID());
       
        
        modU.campoCorreo.setText(user.getListaUsuario().get(fila).getCorreo());
        modU.campoTelefono.setText(user.getListaUsuario().get(fila).getTelefono());
        modU.ComboTipoU.setSelectedIndex(fila);
        modU.comoEstatus.setSelectedIndex(fila);
       
        
     
    }
    
        
    @Override
    public void actionPerformed(ActionEvent e) {
     //Boton del panel inicio de sesion
     if(e.getSource()== is.btnIngresar){
       
         String correo = is.campoCorreo.getText();
         char pass[] = is.campoContraseña.getPassword();
         String password = new String(pass);
         
        if(validarCampoIS()){
           if(userBuscado(password,correo)){
               
         ventanaP.setSize(720,520);
         ventanaP.setLocation(0,0);
         vi.panelVI.removeAll();
         vi.panelVI.add(ventanaP);
         vi.panelVI.revalidate();
         vi.panelVI.repaint();
         pi.setSize(580,470);
         pi.setLocation(0,0);
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(pi);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         ventanaP.btnInicio.setBackground(Color.GRAY);
         ventanaP.btnUsuario.setBackground(new Color(255,255,255));
         ventanaP.btnOF.setBackground(new Color(255,255,255));
         ventanaP.btnEstudiante.setBackground(new Color(255,255,255));
         ventanaP.btnProfesor.setBackground(new Color(255,255,255)); 
           }else{
               JOptionPane.showMessageDialog(null,"Correo o Contraseña incorrecta. Intente nuevamente","",1);
           } 
        }else{
            JOptionPane.showMessageDialog(null,"Existe algún campo vacio. No permitido","",1);
        }
         
     }
     
     if(e.getSource()==ventanaP.btnCerrarSesion){
         int op =  JOptionPane.showConfirmDialog(null, "¿Desea cerrar sesión?", "Aviso", JOptionPane.YES_NO_OPTION);
         if(op==0){
             vi.panelVI.removeAll();
             vi.panelVI.add(is);
             vi.panelVI.revalidate();
             vi.panelVI.repaint();
             borrarCampoIS();
         }
         
     }


    //BOTONES VENTANA PRINCIPAL
       
       //Boton Inicio
       if(e.getSource()== ventanaP.btnInicio){
         pi.setSize(580,470);
         pi.setLocation(0,0);  
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(pi);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         ventanaP.btnInicio.setBackground(Color.GRAY);
         ventanaP.btnUsuario.setBackground(new Color(255,255,255));
         ventanaP.btnOF.setBackground(new Color(255,255,255));
         ventanaP.btnEstudiante.setBackground(new Color(255,255,255));
         ventanaP.btnProfesor.setBackground(new Color(255,255,255)); 
         ventanaP.btnCerrarSesion.setBackground(new Color(255,255,255));
         ventanaP.btnMinimizar.setBackground(new Color(255,255,255));
         ventanaP.btnSalirVP.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()== ventanaP.btnUsuario){
         barraGestionU.setSize(580,30);
         barraGestionU.setLocation(0,0);
         pu.setSize(580,470);
         pu.setLocation(0,0);  
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(barraGestionU);
         ventanaP.PanelMuestra.add(pu);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         ventanaP.btnInicio.setBackground(new Color(255,255,255));
         ventanaP.btnUsuario.setBackground(Color.GRAY);
         ventanaP.btnOF.setBackground(new Color(255,255,255));
         ventanaP.btnEstudiante.setBackground(new Color(255,255,255));
         ventanaP.btnProfesor.setBackground(new Color(255,255,255)); 
       }
       
       if(e.getSource()== ventanaP.btnOF){
         barraGestion.setSize(580,30);
         barraGestion.setLocation(0,0);
         pof.setSize(580,470);
         pof.setLocation(0,0);  
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(barraGestion);
         ventanaP.PanelMuestra.add(pof);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         ventanaP.btnInicio.setBackground(new Color(255,255,255));
         ventanaP.btnUsuario.setBackground(new Color(255,255,255));
         ventanaP.btnOF.setBackground(Color.GRAY);
         ventanaP.btnEstudiante.setBackground(new Color(255,255,255));
         ventanaP.btnProfesor.setBackground(new Color(255,255,255)); 
       }
       
       if(e.getSource()== ventanaP.btnEstudiante){
           barraEst.setSize(580,30);
         barraEst.setLocation(0,0);
         pest.setSize(580,470);
         pest.setLocation(0,0);  
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(barraEst);
         ventanaP.PanelMuestra.add(pest);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         ventanaP.btnInicio.setBackground(new Color(255,255,255));
         ventanaP.btnUsuario.setBackground(new Color(255,255,255));
         ventanaP.btnOF.setBackground(new Color(255,255,255));
         ventanaP.btnEstudiante.setBackground(Color.GRAY);
         ventanaP.btnProfesor.setBackground(new Color(255,255,255)); 
       }
       
       if(e.getSource()== ventanaP.btnProfesor){
         barraProf.setSize(580,30);
         barraProf.setLocation(0,0);
         pprof.setSize(580,470);
         pprof.setLocation(0,0);  
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(barraProf);
         ventanaP.PanelMuestra.add(pprof);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         ventanaP.btnInicio.setBackground(new Color(255,255,255));
         ventanaP.btnUsuario.setBackground(new Color(255,255,255));
         ventanaP.btnOF.setBackground(new Color(255,255,255));
         ventanaP.btnEstudiante.setBackground(new Color(255,255,255));
         ventanaP.btnProfesor.setBackground(Color.GRAY); 
       }
       
       //BOTONES BARRA GESTION USUARIO
       
       if(e.getSource()==barraGestionU.btnAñadir){
           barraGestionU.setSize(580,30);
           barraGestionU.setLocation(0,0);
           agregarP.setSize(580,500);
           agregarP.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraGestionU);
           ventanaP.PanelMuestra.add(agregarP);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraGestionU.btnAñadir.setBackground(Color.GRAY);
           barraGestionU.btnEliminarU.setBackground(new Color(255,255,255));
           barraGestionU.btnListadoU.setBackground(new Color(255,255,255));
           barraGestionU.btnModificarU.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraGestionU.btnListadoU){
           cargarTablaUsuario();
           barraGestionU.setSize(580,30);
           barraGestionU.setLocation(0,0);
           gestionList.setSize(580,500);
           gestionList.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraGestionU);
           ventanaP.PanelMuestra.add(gestionList);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraGestionU.btnAñadir.setBackground(new Color(255,255,255));
           barraGestionU.btnEliminarU.setBackground(new Color(255,255,255));
           barraGestionU.btnListadoU.setBackground(Color.GRAY);
           barraGestionU.btnModificarU.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraGestionU.btnEliminarU){
            int fila = gestionList.Lista.getSelectedRow();
            if (fila >= 0){
                Collections.reverse(user.getListaUsuario());
                user.getListaUsuario().remove(fila);
                Collections.reverse(user.getListaUsuario());
                cargarTablaUsuario();
                JOptionPane.showMessageDialog(null, "El Usuario ha sido eliminado con éxito", "", 1);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un usuario de la lista", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
           
       }
       
       if(e.getSource()==barraGestionU.btnModificarU){
           int fila = gestionList.Lista.getSelectedRow();
           if(fila>=0){
             
               modificarU(fila);
           /*    if(e.getSource()== modU.btnModU){
                 boolean flag = validarModU();
                  if(flag){
                      if(modU.campoID.getText().equals(user.getListaUsuario().get(fila).getID())){
                           String idMod= user.getListaUsuario().get(fila).getID();
                      }else{
                          if(p.validarID(modU.campoID.getText())){
                              String id = modU.campoID.getText();
                              if("Administrador".equals(modU.ComboTipoU.getSelectedItem())){
                                String  contra = "123";
                                String tipoU = modU.ComboTipoU.getSelectedItem().toString();
                                String nom = user.getListaUsuario().get(fila).getNombre();
                                String apellido = user.getListaUsuario().get(fila).getApellido();
                                String correo = user.getListaUsuario().get(fila).getCorreo();
                                String tlf = user.getListaUsuario().get(fila).getTelefono();
                                String estatus = modU.comoEstatus.getSelectedItem().toString();
                                
                             Administrador admin = new Administrador(contra,tipoU,id,nom,apellido,correo,tlf,estatus);
                            user.agregarAdmin(admin);
                            JOptionPane.showMessageDialog(null, "El Administrador ha sido actualizado con éxito", "", 1);
                             borrarCampoAgregarP();
                          }
                              
                          }
                      }
               }else{
                    JOptionPane.showMessageDialog(null, "llenar los datos antes de modificar", "Advertencia", JOptionPane.WARNING_MESSAGE);
                  }
           }  */
       }else{
              JOptionPane.showMessageDialog(null, "Seleccione un usuario de la lista", "Advertencia", JOptionPane.WARNING_MESSAGE);
           }
      }
       
       if(e.getSource()==modU.btnModU){
         
          
             
           
       }
       
       
       
       if(e.getSource()==barraGestion.btnCrear){
           if(listaEst.isEmpty()){
            JOptionPane.showMessageDialog(null, "Se necesitan estudiantes para crear una Oferta Formativa", "Advertencia", JOptionPane.WARNING_MESSAGE);
           }else{
         barraGestion.setSize(580,30);
         barraGestion.setLocation(0,0);
         agregarOF.setSize(580,500);
         agregarOF.setLocation(0,0);  
         ventanaP.PanelMuestra.removeAll();
         ventanaP.PanelMuestra.add(barraGestion);
         ventanaP.PanelMuestra.add(agregarOF);
         ventanaP.PanelMuestra.revalidate();
         ventanaP.PanelMuestra.repaint();
         barraGestion.btnCrear.setBackground(Color.GRAY);
         barraGestion.btnEliminar.setBackground(new Color(255,255,255));
         barraGestion.btnModificar.setBackground(new Color(255,255,255));
         barraGestion.btnListar.setBackground(new Color(255,255,255));
       }
      }
       
       if(e.getSource()==barraGestion.btnEliminar){ //ELIMINA OFERTA FORMATIVA
            int fila = gestionList.Lista.getSelectedRow();
            if (fila >= 0){
                Collections.reverse(listaOF);
                listaOF.remove(fila);
                Collections.reverse(listaOF);
                cargarTablaOF();
                JOptionPane.showMessageDialog(null, "La Oferta Formativa ha sido eliminado con éxito", "", 1);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione una Oferta Formativa de la lista", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
       }
       
       if(e.getSource()==barraGestion.btnListar){
           cargarTablaOF();
           barraGestion.setSize(580,30);
           barraGestion.setLocation(0,0);
           gestionList.setSize(580,500);
           gestionList.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraGestion);
           ventanaP.PanelMuestra.add(gestionList);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraGestion.btnCrear.setBackground(new Color(255,255,255));
           barraGestion.btnEliminar.setBackground(new Color(255,255,255));
           barraGestion.btnListar.setBackground(Color.GRAY);
           barraGestion.btnModificar.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraGestion.btnModificar){
           
       }
               
               
       //BARRA GESTION ESTUDIANTE
       if(e.getSource()==barraEst.btnAñadirEst){
           barraEst.setSize(580,30);
           barraEst.setLocation(0,0);
           agregarEst.setSize(580,500);
           agregarEst.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraEst);
           ventanaP.PanelMuestra.add(agregarEst);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraEst.btnAñadirEst.setBackground(Color.GRAY);
           barraEst.btnEliminarEst.setBackground(new Color(255,255,255));
           barraEst.btnListarEst.setBackground(new Color(255,255,255));
           barraEst.btnModificarEst.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraEst.btnEliminarEst){
            int fila = gestionList.Lista.getSelectedRow();
            if (fila >= 0){
                Collections.reverse(listaEst);
                listaEst.remove(fila);
                Collections.reverse(listaEst);
                cargarTablaEstudiante();
                JOptionPane.showMessageDialog(null, "El Estudiante ha sido eliminado con éxito", "", 1);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un Estudiante de la lista", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
       }
       
       if(e.getSource()==barraEst.btnListarEst){
           cargarTablaEstudiante();
           barraEst.setSize(580,30);
           barraEst.setLocation(0,0);
           gestionList.setSize(580,500);
           gestionList.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraEst);
           ventanaP.PanelMuestra.add(gestionList);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraEst.btnAñadirEst.setBackground(new Color(255,255,255));
           barraEst.btnEliminarEst.setBackground(new Color(255,255,255));
           barraEst.btnListarEst.setBackground(Color.GRAY);
           barraEst.btnModificarEst.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraEst.btnModificarEst){
           
       }
       
       //BARRA GESTION DE PROFESOR
       if(e.getSource()==barraProf.btnAñadirProf){
           barraProf.setSize(580,30);
           barraProf.setLocation(0,0);
           agregarProf.setSize(580,500);
           agregarProf.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraProf);
           ventanaP.PanelMuestra.add(agregarProf);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraProf.btnAñadirProf.setBackground(Color.GRAY);
           barraProf.btnEliminarProf.setBackground(new Color(255,255,255));
           barraProf.btnListarProf.setBackground(new Color(255,255,255));
           barraProf.btnModificarProf.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraProf.btnEliminarProf){
            int fila = gestionList.Lista.getSelectedRow();
            if (fila >= 0){
                Collections.reverse(listaProf);
                listaProf.remove(fila);
                Collections.reverse(listaProf);
                cargarTablaProf();
                JOptionPane.showMessageDialog(null, "El Profesor ha sido eliminado con éxito", "", 1);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un profesor de la lista", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
       }
       
       if(e.getSource()==barraProf.btnListarProf){
           cargarTablaProf();
           barraProf.setSize(580,30);
           barraProf.setLocation(0,0);
           gestionList.setSize(580,500);
           gestionList.setLocation(0,0);
           ventanaP.PanelMuestra.removeAll();
           ventanaP.PanelMuestra.add(barraProf);
           ventanaP.PanelMuestra.add(gestionList);
           ventanaP.PanelMuestra.revalidate();
           ventanaP.PanelMuestra.repaint();
           barraProf.btnAñadirProf.setBackground(new Color(255,255,255));
           barraProf.btnEliminarProf.setBackground(new Color(255,255,255));
           barraProf.btnListarProf.setBackground(Color.GRAY);
           barraProf.btnModificarProf.setBackground(new Color(255,255,255));
       }
       
       if(e.getSource()==barraProf.btnModificarProf){
           
       }
       
       //Boton agregar Usuario nuevo
         if(e.getSource()== agregarP.btnAñadirF){
           boolean flag = validarCampoAgregarP();
            if(flag){
                if(idRepetida(agregarP.campoID.getText())){
                    JOptionPane.showMessageDialog(null, "La ID está repetida", "Advertencia", JOptionPane.WARNING_MESSAGE);
                }else{ 
                    if(correoRepetido(agregarP.campoCorreo.getText())){
                        JOptionPane.showMessageDialog(null, "El correo está repetido", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    }else{
                       if((p.validarNombre(agregarP.campoNombre.getText())) && (p.validarNumero(agregarP.campoTelefono.getText())) ){
                        
                        if( p.validarCorreo(agregarP.campoCorreo.getText()) && (p.validarID(agregarP.campoID.getText()))){
                            
                            String id = agregarP.campoID.getText();
                            String nom = agregarP.campoNombre.getText();
                            String tlf = agregarP.campoTelefono.getText();
                      
                       if( p.validarApellido(agregarP.campoApellido.getText())){
                           String correo = agregarP.campoCorreo.getText();
                           String apellido = agregarP.campoApellido.getText();
                           String tipoU = agregarP.ComboTipoU.getSelectedItem().toString();
                           String estatus = agregarP.comoEstatus.getSelectedItem().toString();
                           String contra = agregarP.CampoContraseña.getText();
                           
                          if("Administrador".equals(tipoU)){
                             Administrador admin = new Administrador(contra,tipoU,id,nom,apellido,correo,tlf,estatus);
                            user.agregarAdmin(admin);
                            JOptionPane.showMessageDialog(null, "El nuevo Administrador ha sido ingresado con éxito", "", 1);
                             borrarCampoAgregarP();
                          }
                          
                          if("Coordinador".equals(tipoU)){
                             Coordinador coord = new Coordinador(contra,tipoU,id,nom,apellido,correo,tlf,estatus);
                             user.agregarCoord(coord);
                             JOptionPane.showMessageDialog(null, "El nuevo Coordinador ha sido ingresado con éxito", "", 1);
                             borrarCampoAgregarP();
                          }
                          
                          if("Analista".equals(tipoU)){
                             Analista analist = new Analista(contra,tipoU,id,nom,apellido,correo,tlf,estatus);
                             user.agregarAnalista(analist);
                             JOptionPane.showMessageDialog(null, "El nuevo Analista ha sido ingresado con éxito", "", 1);
                             borrarCampoAgregarP();
                          }
                          
                       }
                      }  
                      
                    }
                }
               }
            }else{
                JOptionPane.showMessageDialog(null, "Llena todos los campos antes de agregar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            } 
       }
       
        //BOTON AGREGAR A NUEVO ESTUDIANTE
      if(e.getSource()==agregarEst.btnAñadirEst){
          boolean flag = validarCampoAgregarEst();
          if(flag){ 
              if(idRepetidaEst(agregarEst.campoID.getText())) {
                   JOptionPane.showMessageDialog(null,"ID en el sistema, ingrese otra","Advertencia",JOptionPane.WARNING_MESSAGE);
              }else{ 
                 if(correoRepetidoEst(agregarEst.campoCorreo.getText())){
                    JOptionPane.showMessageDialog(null,"Correo ya en el sistema, use otro","Advertencia",JOptionPane.WARNING_MESSAGE);
              }else{
              if(p.validarID(agregarEst.campoID.getText()) && p.validarCorreo(agregarEst.campoCorreo.getText()) && p.validarNumero(agregarEst.campoTelefono.getText())){

                  
                 if(p.validarNombre(agregarEst.campoNombre.getText()) && p.validarApellido(agregarEst.campoApellido.getText()) && estudiante.validarNumero(agregarEst.CampoCursoEST.getText())){
                       
                     try {
                      Number numero = formato.parse(agregarEst.campoNota.getText());
                       double nota1 = numero.doubleValue();
                       
                       if(estudiante.validaRangoNota(nota1) && estudiante.validarNumeroConDecimales(agregarEst.campoNota.getText())){
                           
                            String tlf = agregarEst.campoTelefono.getText();
                            String nombreEst = agregarEst.campoNombre.getText();
                            String apellidoEst = agregarEst.campoApellido.getText();
                            String curso = agregarEst.CampoCursoEST.getText();
                            String estatus = agregarEst.comoEstatus.getSelectedItem().toString();
                            String idEst = agregarEst.campoID.getText();
                            String correoEst = agregarEst.campoCorreo.getText();
                            String  nota = agregarEst.campoNota.getText();
                            
                         Estudiante est = new Estudiante(curso,idEst,nombreEst,apellidoEst,correoEst,tlf,estatus,nota);
                        listaEst.add(est);
                        JOptionPane.showMessageDialog(null,"El estudiante ha sido ingresado con éxito","",1);
                        borrarCampoAgregarEst();
                        }
                     } catch (ParseException ex) {
                        JOptionPane.showMessageDialog(null,"No se pueden ingresar caracteres","Advertencia",JOptionPane.WARNING_MESSAGE);
                     }
                           
                
                   }
                 }
                }
              }
          }else{
              JOptionPane.showMessageDialog(null,"Llena todos los campos antes de agregar","Adverencia",JOptionPane.WARNING_MESSAGE);
          }
      }
         
     //BOTON AGREGAR NUEVO PROFESOR
     if(e.getSource()==agregarProf.btnAñadirProf){
        boolean flag = validarCampoAgregarProf();
        
        if(flag){
            if(idRepetida(agregarProf.campoID.getText())){
                JOptionPane.showMessageDialog(null,"ID en el sistema, ingrese otra","Advertencia",JOptionPane.WARNING_MESSAGE);
            }else{
                if(correoRepetido(agregarProf.campoCorreo.getText())){
                    JOptionPane.showMessageDialog(null,"Correo en el sistema, ingrese otro","Advertencia",JOptionPane.WARNING_MESSAGE);
                }else{
                    if(prof.validarNombre(agregarProf.campoNombre.getText()) && prof.validarApellido(agregarProf.campoApellido.getText()) && prof.validarID(agregarProf.campoID.getText())){
                        
                      if(prof.validarCorreo(agregarProf.campoCorreo.getText()) &&prof.validarNumero(agregarProf.campoTelefono.getText()) && 
                          prof.validarTitulo(agregarProf.campoTitulacion.getText())){
                          
                          String nombreProf = agregarProf.campoNombre.getText();
                          String apellidoProf = agregarProf.campoApellido.getText();
                          String idProf = agregarProf.campoID.getText();
                          String correoProf = agregarProf.campoCorreo.getText();
                          String tlfProf = agregarProf.campoTelefono.getText();
                          String titulo = agregarProf.campoTitulacion.getText();
                          String estatus = agregarProf.comoEstatus.getSelectedItem().toString();
                          String contraProf = agregarProf.CampoContraseña.getText();
                          
                          Profesor prof = new Profesor(titulo,contraProf,idProf,nombreProf,apellidoProf,correoProf,tlfProf,estatus);
                          listaProf.add(prof);
                          user.agregarProf(prof);
                          JOptionPane.showMessageDialog(null,"El estudiante ha sido ingresado con éxito","",1);
                          borrarCampoAgregarProf();
                      }
                    }   
                    
                }
            }
        }else{
            JOptionPane.showMessageDialog(null,"Llena todos los campos antes de agregar","Advertencia",JOptionPane.WARNING_MESSAGE);
        }
     }
      
     if(e.getSource()== agregarOF.btnAñadirOF){
         boolean flag = validarCampoOF();
          if(flag){
              if(codigoRepetido(agregarOF.CampoCodigoOF.getText())){
                  JOptionPane.showMessageDialog(null,"Codigo en uso, agregue otro","Advertencia",JOptionPane.WARNING_MESSAGE);
              }else{
                  if(encuentraCurso(agregarOF.CampoCursoEOF.getText())){
                      if(OF.validarNombre(agregarOF.CampoNombreOF.getText()) && OF.validarCodigo(agregarOF.CampoCodigoOF.getText()) && OF.validarHoras(agregarOF.CampoHorasOF.getText())){
                          
                          if(OF.validarCosto(agregarOF.CampoCostoOF.getText()) && OF.validarEdicion(agregarOF.CampoEdicionOF.getText()) && OF.validarCurso(agregarOF.CampoCursoEOF.getText())){
                              String nombre = agregarOF.CampoNombreOF.getText();
                              String codigo = agregarOF.CampoCodigoOF.getText();
                              String horas = agregarOF.CampoHorasOF.getText();
                              String costo = agregarOF.CampoCostoOF.getText();
                              String edicion = agregarOF.CampoEdicionOF.getText();
                              String curso = agregarOF.CampoCursoEOF.getText();
                              String descripcion = agregarOF.CampoDescripcionOF.getText();
                              String tipoOF = agregarOF.ComboTipo.getSelectedItem().toString();
                              for(int i=0;i<listaEst.size();i++){
                                  if(listaEst.get(i).getCurso().equals(curso)){
                                      Estudiante estu = listaEst.get(i);
                                     
                                      OF.introducirU(estu);
                                  }
                              }
                              OfertaFormativa of = new OfertaFormativa(nombre,tipoOF,horas,descripcion,codigo,costo,edicion);
                              listaOF.add(of);
                              JOptionPane.showMessageDialog(null,"La Oferta Formativa ha sido agregada con éxito","",1);
                              borrarCampoOF();
                          }
                          
                      }
                  }else{
                      JOptionPane.showMessageDialog(null,"Curso no registrado en el sistema. Asegurese de ingresar un curso válido","Advertencia",JOptionPane.WARNING_MESSAGE);
                  }
              }
          }else{
              JOptionPane.showMessageDialog(null,"Llena todos los campos antes de agregar","Advertencia",JOptionPane.WARNING_MESSAGE);
          }
         
     }
     
      
    }
    
}
