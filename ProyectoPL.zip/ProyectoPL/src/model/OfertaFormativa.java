/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Aspire
 */
public class OfertaFormativa {
    private String nombre;
    private String tipo;
    private String tHoras;  //total de horas de la oferta formativa
    private String descripcion;
    private String codigo;
    private String costo;
    private String edicion;
    private ArrayList<Persona> listaParticipe; //lista de estudiantes y profesor que estara en la OF

    //CONSTRUCTORES
    public OfertaFormativa(String nombre, String tipo, String tHoras, String descripcion, String codigo, String costo, String edicion) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.tHoras = tHoras;
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.costo = costo;
        this.edicion = edicion;
        this.listaParticipe = new ArrayList<>();
    }
    
    public OfertaFormativa(){
        nombre = "";
        tipo = "";
        tHoras = "";
        descripcion = "";
        codigo = "";
        costo = "";
        edicion = "";
        this.listaParticipe = new ArrayList<>();
    }

    //GETTERS Y SETTERS
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String gettHoras() {
        return tHoras;
    }

    public void settHoras(String tHoras) {
        this.tHoras = tHoras;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCosto() {
        return costo;
    }

    public void setCosto(String costo) {
        this.costo = costo;
    }

    public String getEdicion() {
        return edicion;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    public ArrayList<Persona> getListaUsuarios() {
        return listaParticipe;
    }

    public void setListaUsuarios(ArrayList<Persona> listaUsuarios) {
        this.listaParticipe = listaUsuarios;
    }
    
    
    public void introducirU(Profesor p){
        listaParticipe.add(p);
    }
    
    public void introducirU(Estudiante e){
        listaParticipe.add(e);
    }
    
    public void eliminarU(Profesor p){
        listaParticipe.remove(p);
    }
    
    public void eliminarU(Estudiante e){
        listaParticipe.remove(e);
    }
    
     public boolean validarNombre(String nombre) { //Valida nombre 
       int i,as;
        char a;
        for (i=0; nombre.length()>i;i++){
            a= nombre.charAt(i);
            as= (int)a;
            if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                JOptionPane.showMessageDialog(null, "Nombre inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            } 
            if((as>=48 && 57>=as)==true){
                JOptionPane.showMessageDialog(null, "Nombre inválido.\nContiene algun dígito", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }       
        }            
        return true;
    }  
     
     public boolean validarCodigo (String codigo) { //Valida Codigo
        
                int i,as;
                char a;
                for (i=0; codigo.length()>i;i++){
                    a= codigo.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= codigo.length();
                        JOptionPane.showMessageDialog(null, "Código inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= codigo.length();
                        JOptionPane.showMessageDialog(null, "Código inválido.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
        
        }
     
      public boolean validarCosto (String costo) { //Valida cedula
        int i,as;
        char a;
        for (i=0; costo.length()>i;i++){
            a= costo.charAt(i);
            as= (int)a;
            if (!((as>=48 && as<=57) || (as==44))){
                JOptionPane.showMessageDialog(null, "No se pueden escribir caracteres en esta opción", "Error", 0);
                return false;
            } 
        }
        return true;
    }
     
     public boolean validarHoras (String horas) { //Valida las horas de la OF
        
                int i,as;
                char a;
                for (i=0; horas.length()>i;i++){
                    a= horas.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= horas.length();
                        JOptionPane.showMessageDialog(null, "Hora inválida.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= horas.length();
                        JOptionPane.showMessageDialog(null, "Hora inválida.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
        
        }
     
     public boolean validarEdicion (String ed) { //Valida las horas de la OF
        
                int i,as;
                char a;
                for (i=0; ed.length()>i;i++){
                    a= ed.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= ed.length();
                        JOptionPane.showMessageDialog(null, "Edición inválida.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= ed.length();
                        JOptionPane.showMessageDialog(null, "Edición inválida.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
        
        }
     
     public boolean validarCurso (String curso) { //Valida curso
        int i,as;
        char a;
                for (i=0; curso.length()>i;i++){
                    a= curso.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= curso.length();
                        JOptionPane.showMessageDialog(null, "Curso inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= curso.length();
                        JOptionPane.showMessageDialog(null, "Curso inválido.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
    }
     
     
    
}
