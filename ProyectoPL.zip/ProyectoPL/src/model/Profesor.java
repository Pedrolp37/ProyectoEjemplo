/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import javax.swing.JOptionPane;

/**
 *
 * @author Aspire
 */
public class Profesor extends Persona{
    private String titulacion;
    private String contraseña;

    public Profesor(String titulacion, String contraseña,String ID, String nombre, String apellido, String correo, String telefono, String estatus) {
        super( ID, nombre, apellido, correo, telefono, estatus);
        this.titulacion = titulacion;
        this.contraseña = contraseña;
    }
    
    public Profesor(){
        nombre = "profesor";
        correo = "prof@gmail.com";
        titulacion = "Sistemas";
        contraseña = "1234";
    }

    public String getTitulacion() {
        return titulacion;
    }

    public void setTitulacion(String titulacion) {
        this.titulacion = titulacion;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
    
    public boolean validarTitulo(String titulo) { //Valida nombre 
       int i,as;
        char a;
        for (i=0; titulo.length()>i;i++){
            a= titulo.charAt(i);
            as= (int)a;
            if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                JOptionPane.showMessageDialog(null, "Titulo inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            } 
            if((as>=48 && 57>=as)==true){
                JOptionPane.showMessageDialog(null, "Titulo inválido.\nContiene algun dígito", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }       
        }            
        return true;
    }  
    
}
