/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.text.ParseException;
import java.util.ArrayList;
import javax.swing.JOptionPane;




public class Estudiante extends Persona{
    private String curso;
    private String nota;
    
    public Estudiante(String curso,String ID, String nombre, String apellido, String correo, String telefono, String estatus,String nota){
        super( ID,nombre,apellido, correo,telefono, estatus);
        this.curso = curso;
        this.nota = nota;
    }
    
    public Estudiante(){
        curso = "0";
        nota = "0";
    }

    public String getCurso(){
        return curso;
    }
    
    public void setCurso(String curso){
        this.curso = curso;
    }
    
    public String getNota() {
        return nota;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }
    
    @Override
    public boolean validarNumero (String numero) { 
        int i,as;
        char a;
                for (i=0; numero.length()>i;i++){
                    a= numero.charAt(i);
                    as= (int)a;
                    if(((as>=91 && 96>=as) ||  (as>=33 && as<=47) || (as>=58 && 64>= as) || (as>=123 && 126>=as))==true ){
                        i= numero.length();
                        JOptionPane.showMessageDialog(null, "Curso inválido.\nContiene algun carácter especial", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    } 
                    if(((as>=65 && 90>=as) ||( as>=97 && 122>=as))==true){
                        i= numero.length();
                        JOptionPane.showMessageDialog(null, "Curso inválido.\nExpresión alfanumérica", "Advertencia", JOptionPane.WARNING_MESSAGE);
                        return false;
                    }      
                }            
            
            return true;
    }
    
   
   
    public boolean validaRangoNota(Double nota){
        boolean permitido = true;
     
      
        if(!(nota>=0 && nota<=20)){
            JOptionPane.showMessageDialog(null,"Numero debe estar entre 0 y 20","Advertencia", JOptionPane.WARNING_MESSAGE);
            return !permitido;
        }else{
         
            return permitido;
        }
      
    }
    
    public boolean validarNumeroConDecimales (String nota) { //Valida nota
        int i,as;
        Character a;
        for (i=0; nota.length()>i;i++){
            a= nota.charAt(i);
            as= (int)a;
            if (!((as>=48 && as<=57) || (as==44))){
                JOptionPane.showMessageDialog(null, "No se pueden escribir caracteres en esta opción (Solo con , )", "Error", 0);
                return false;
            } 
        }
        return true;
    }
    
}
