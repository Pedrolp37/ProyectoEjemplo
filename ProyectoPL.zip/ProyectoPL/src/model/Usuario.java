/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Usuario {
    private ArrayList<Persona> listaUsuario;

    public Usuario() {
        this.listaUsuario = new ArrayList<>();
    }

    public ArrayList<Persona> getListaUsuario() {
        return listaUsuario;
    }

    public void setListaUsuario(ArrayList<Persona> listaUsuario) {
        this.listaUsuario = listaUsuario;
    }
    
    public void agregarAdmin(Administrador admin){
        listaUsuario.add(admin);
    }
    
    public void eliminarAdmin(Administrador admin){
        listaUsuario.remove(admin);
    }
    
     public void agregarCoord(Coordinador coord){
        listaUsuario.add(coord);
    }
    
    public void eliminarCoord(Coordinador coord){
        listaUsuario.remove(coord);
    }
    
     public void agregarAnalista(Analista analist){
        listaUsuario.add(analist);
    }
    
    public void eliminarAnalista(Analista analist){
        listaUsuario.remove(analist);
    }
    
    public void agregarProf(Profesor prof){
        listaUsuario.add(prof);
    }
    
    public void eliminarProf(Profesor prof){
        listaUsuario.remove(prof);
    }
    
    
}
