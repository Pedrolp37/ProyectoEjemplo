/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Aspire
 */
public class Coordinador extends Persona{
    private String Contrasena;
    private String rol;

    public Coordinador(String Contrasena, String rol,String ID, String nombre, String apellido, String correo, String telefono, String estatus) {
        super( ID,nombre, apellido,correo, telefono, estatus);
        this.Contrasena = Contrasena;
        this.rol = rol;
    }
    
    public Coordinador(){
        ID = "321";
        nombre = "Coordinador";
        apellido = "Sistema";
        correo = "coord@gmail.com";
        Contrasena = "1234";
        rol = "Coordinador";
        telefono = "0421382";
        estatus = "Activo";
    }

    public String getContrasena() {
        return Contrasena;
    }

    public void setContrasena(String Contrasena) {
        this.Contrasena = Contrasena;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
    
    
    
    
    
}
